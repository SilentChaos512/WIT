package net.silentchaos512.wit.proxy;

public class CommonProxy {

  public void preInit() {

  }

  public void init() {

    registerKeyHandlers();
  }
  
  public void postInit() {

  }
  
  public void registerKeyHandlers() {

  }
}
